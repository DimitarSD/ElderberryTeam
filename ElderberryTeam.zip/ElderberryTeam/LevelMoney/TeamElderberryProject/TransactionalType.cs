﻿namespace TeamElderberryProject
{
    public enum TransactionType
    {
        RegularIncome,
        IrregularIncome,
        RegularExpense,
        IrregularExpense
    }
}