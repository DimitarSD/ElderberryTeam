﻿namespace TeamElderberryProject.Interfaces
{
    public interface IExpense
    {
    }
}