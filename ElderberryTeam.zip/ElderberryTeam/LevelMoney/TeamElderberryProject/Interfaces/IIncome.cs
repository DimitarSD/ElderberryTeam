﻿namespace TeamElderberryProject.Interfaces
{
    public interface IIncome
    {
    }
}