﻿namespace TeamElderberryProject.Interfaces
{
    public interface IExporter
    {
        void Export(ITransaction transaction);
    }
}
